import React from 'react';
import { useParams } from 'react-router-dom';
import { Services } from '../Services';
import { Link } from 'react-router-dom';

const Servicesection6 = () => {


  const { serviceId, subServiceId } = useParams();

  const service = Services.find((s) => s.id === parseInt(serviceId));
  const subService = service?.subtitles.find((sub) => sub.subid === parseInt(subServiceId));

  if (!service || !subService) return <div>Sub-service not found</div>;


  return (
    <div className="mt-24 xl:pr-10 xl:pl-12 lg:pl-10 lg:pr-8 md:pl-8 md:pr-6 pl-6 pr-4">
      
      <div className="mb-14">
        <h4 className="text-4xl sm:text-5xl font-khula tracking-[1px] font-md">Related Sub-Survices</h4>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-8  mb-8">
      {service.subtitles.map((sub) => (
          <div key={sub.subid} className="sm:pb-10">
            <h4 className="text-2xl font-khula hover-underline-animation tracking-[1px] cursor-pointer font-md mb-2"> <span >{sub.subtitle}</span> </h4>
            <p className="text-md tracking-[1px] font-raleway sm:text-[16px]">{sub.subcontent.split(' ').slice(0, 10).join(' ')}{sub.subcontent.split(' ').length > 10 ? '...' : ''}</p>

            <Link to={`/${service.id}/${sub.subtitle}/${sub.subid}`} className="text-cyan-500 font-bold mt-2 cursor-pointer sm:sm:text-[16px] tracking-[1px] font-raleway "
            onClick={() => {
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}>Read more</Link>
          </div>
        ))}
      </div>

    </div>
  );
};

export default Servicesection6;
