import React from 'react';
import { Services } from '../Services';
import { useParams } from 'react-router-dom';


const Servicesection3 = () => {




    const { serviceId, subServiceId } = useParams();

    const service = Services.find((s) => s.id === parseInt(serviceId));
    const subService = service?.subtitles.find((sub) => sub.subid === parseInt(subServiceId));
  
    if (!service || !subService) return <div>Sub-service not found</div>;

  return (
    <div className="relative mb-24">
      <img
        src={subService.subimg}
        alt={subService.subalt}
        className="w-full h-[700px] object-cover"
      />
      
      <div className="absolute inset-0 bg-black bg-opacity-50 "></div>

      <div className="absolute  bottom-10 md:pl-8 pl-6 right-4 md:right-6 lg:right-8 xl:right-10 xl:pl-12 lg:pl-10  text-white text-right">
      
      <h4 className="text-4xl md:text-4xl xl:text-9xl font-khula font-bold text-transparent bg-clip-text bg-gradient-to-r from-brandBlue via-cyan-400 to-cyan-500">
        {subService.subtitle}
      </h4>


      </div>
    </div>
  );
};

export default Servicesection3;
