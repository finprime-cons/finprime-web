import React from 'react';

const Rtext = () => {
  return (
    <div className=" flex justify-center items-center md:pt-20 pb-5 md:pb-20 bg-gray-200 ">
      <div className="flex w-[70%] justify-between px-6">
        <p className="text-xs text-gray-700 md:w-[60%]">
          
        </p>
        <p className="animate-fadeinbottom  text-[18px]  text-gray-700 md:w-[60%] text-left">
          Lorem ipsum dolor sit amet, consectetur adipiscing elit.
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
          Praesent vel lorem a justo elementum aliquam. Nulla facilisi. 
          Fusce scelerisque felis libero, a scelerisque urna feugiat a. 
          Nam euismod dui sed purus gravida convallis.
          Fusce scelerisque felis libero, a scelerisque urna feugiat a. 
          Nam euismod dui sed purus gravida convallis.
          Fusce scelerisque felis libero, a scelerisque urna feugiat a. 
          Nam
        </p>
      </div>
    </div>
  );
};

export default Rtext;
