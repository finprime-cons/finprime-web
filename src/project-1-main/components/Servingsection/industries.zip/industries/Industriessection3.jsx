import React from 'react';
import { Industries } from '../../Industries';
import { useParams } from 'react-router-dom';


const Industriessection3 = () => {




    const { industryId, subIndustryId } = useParams();

    const industry = Industries.find((s) => s.id === parseInt(industryId));
    const subIndustry = industry?.subindustries.find((sub) => sub.id === parseInt(subIndustryId));
  
    if (!industry || !subIndustry) return <div>Sub-Industry not found</div>;




  return (
    <div className="relative mb-24">
      <img
        src={industry.image}
        alt={industry.title}
        className="w-full h-[500px] object-cover"
      />

      <div className="absolute top-20 md:pl-8 pl-6 right-4 md:right-6 lg:right-8 xl:right-10 xl:pl-12 lg:pl-10  text-white text-right">
       
        <h4 className="text-4xl md:text-4xl xl:text-9xl font-khula  font-bold">{industry.title}</h4>

        <p className='text-lg md:pl-20 '></p>
      </div>
    </div>
  );
};

export default Industriessection3;
