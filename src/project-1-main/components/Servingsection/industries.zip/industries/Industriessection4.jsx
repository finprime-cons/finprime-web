import React, { useState } from 'react';
import { Industries } from '../../Industries';
import { Link, useParams } from 'react-router-dom';


const Industriessection4 = () => {




    const { industryId, subIndustryId } = useParams();

    const industry = Industries.find((s) => s.id === parseInt(industryId));
    const subIndustry = industry?.subindustries.find((sub) => sub.id === parseInt(subIndustryId));
  
    if (!industry || !subIndustry) return <div>Sub-Industry not found</div>;



  const [showMore, setShowMore] = useState(false);


  const visibleColumns = showMore ? industry.subindustries : industry.subindustries.slice(0, 3);

  return (
    <div className="mt-20 mb-10 sm:mb-20 xl:mr-10 xl:ml-12 lg:mr-8 lg:ml-10 md:mr-6 md:ml-8 ml-6 mr-4">
      
      <div className="mb-8">
        <h4 className="text-4xl sm:text-5xl font-semibold mb-2">Related Industries</h4>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 wrapper">
      {visibleColumns.map((subIndustry) => (
          <Link 
          to={`/${industry.title}/${industry.id}/${subIndustry.title}/${subIndustry.id}`} 
          key={subIndustry.id} className="border card">
            <img
              src={subIndustry.image}
              alt={`Image ${subIndustry.id}`}
              className="w-full  h-auto "
            />
            <div className="info">
              <h4 className="text-xl font-bold mb-5 sm:text-[28px] text-white">{subIndustry.title}</h4>
              <p className="text-white font-raleway tracking-[1px] text-[16px]">{subIndustry.content.split(' ').slice(0, 10).join(' ')}{subIndustry.content.split(' ').length > 10 ? '...' : ''}</p>
            </div>
          </Link>
          
        ))}
      </div>
      

      {!showMore && (
        <div className="text-center mt-8">
          <button
            className="bg-transparent text-xs md:text-base text-black py-1 sm:py-2 px-4 sm:px-8 border border-black mt-2 mb-10  sm:mb-20
             transition-all duration-300 ease-out hover:bg-gradient-to-r hover:from-brandBlue hover:to-cyan-500 hover:text-white"
            onClick={() => setShowMore(true)}
          >
            Show More
          </button>
        </div>
      )}
    </div>
  );
};

export default Industriessection4;
